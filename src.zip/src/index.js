import scroll from './components/scroll.vue'

const install = function install (Vue, option) {
  Vue.component('scroll', scroll)
}

export default install

export { scroll }
